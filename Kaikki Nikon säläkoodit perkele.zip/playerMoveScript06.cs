﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class playerMoveScript06 : MonoBehaviour
{

    //public int HP = 0;
    public int startingHealth = 100;
    public Slider HPBar;
    public int currentHealth;
    bool isDead;

    void Awake()
    {
        currentHealth = startingHealth;
    }

    void Start()
    {

    }

    void Update()
    {
        HPBar.value = currentHealth;

        if (currentHealth <= 0 && !isDead)
        {
            Death();
        }

    }

    void Death()
    {
        isDead = true;
        transform.position = Vector3.zero;
    }
}
